package com.veritylaboratory.extractor;

import android.content.Context;
import android.speech.tts.TextToSpeech;

import java.util.Locale;

/** Lee texto en voz alta con la voz del celular. */
final class Speaker {
    private static TextToSpeech tts;
    private static boolean ready = false;
    private static String pending = null;

    private Speaker() {}

    static synchronized void speak(Context c, String text) {
        if (text == null) return;
        if (text.length() > 3900) text = text.substring(0, 3900);
        if (tts == null) {
            pending = text;
            tts = new TextToSpeech(c.getApplicationContext(), new TextToSpeech.OnInitListener() {
                @Override public void onInit(int status) {
                    synchronized (Speaker.class) {
                        if (status == TextToSpeech.SUCCESS && tts != null) {
                            int r = tts.setLanguage(new Locale("es", "MX"));
                            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                                tts.setLanguage(new Locale("es"));
                            }
                            ready = true;
                            if (pending != null) { say(pending); pending = null; }
                        }
                    }
                }
            });
            return;
        }
        if (ready) say(text); else pending = text;
    }

    private static void say(String t) {
        try { tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "nexus"); } catch (Exception ignored) {}
    }

    static synchronized void stop() {
        pending = null;
        try { if (tts != null) tts.stop(); } catch (Exception ignored) {}
    }
}
