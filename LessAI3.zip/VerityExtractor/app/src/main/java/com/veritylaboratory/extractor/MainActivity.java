package com.veritylaboratory.extractor;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.io.IOException;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int FILE_PICKER_REQUEST = 4102;
    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private Uri currentDownloadUri;
    private OutputStream currentDownloadStream;
    private String currentDownloadId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(0xFF030811);
        window.setNavigationBarColor(0xFF030811);
        window.getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF030811);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new AndroidDownloadBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileChooserCallback != null) {
                    fileChooserCallback.onReceiveValue(null);
                }
                fileChooserCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"video/*", "image/*"});
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,
                        params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(Intent.createChooser(intent, "Elige un video o una imagen"),
                            FILE_PICKER_REQUEST);
                } catch (Exception e) {
                    fileChooserCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "No se pudo abrir el selector de archivos.",
                            Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_PICKER_REQUEST || fileChooserCallback == null) return;
        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                results = new Uri[count];
                for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
        }
        fileChooserCallback.onReceiveValue(results);
        fileChooserCallback = null;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (fileChooserCallback != null) {
            fileChooserCallback.onReceiveValue(null);
            fileChooserCallback = null;
        }
        cancelCurrentDownload();
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private synchronized void cancelCurrentDownload() {
        try { if (currentDownloadStream != null) currentDownloadStream.close(); } catch (Exception ignored) {}
        currentDownloadStream = null;
        if (currentDownloadUri != null) {
            try { getContentResolver().delete(currentDownloadUri, null, null); } catch (Exception ignored) {}
        }
        currentDownloadUri = null;
        currentDownloadId = null;
    }

    private final class AndroidDownloadBridge {
        @JavascriptInterface
        public synchronized String beginDownload(String requestedName, String mimeType) {
            cancelCurrentDownload();
            try {
                String safeName = sanitizeFilename(requestedName);
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
                values.put(MediaStore.MediaColumns.MIME_TYPE,
                        mimeType == null || mimeType.trim().isEmpty() ? "audio/mpeg" : mimeType);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                currentDownloadUri = getContentResolver().insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (currentDownloadUri == null) return "";
                currentDownloadStream = getContentResolver().openOutputStream(currentDownloadUri, "w");
                if (currentDownloadStream == null) {
                    getContentResolver().delete(currentDownloadUri, null, null);
                    currentDownloadUri = null;
                    return "";
                }
                currentDownloadId = UUID.randomUUID().toString();
                return currentDownloadId;
            } catch (Exception e) {
                cancelCurrentDownload();
                return "";
            }
        }

        @JavascriptInterface
        public synchronized boolean appendDownloadChunk(String id, String base64Chunk) {
            if (currentDownloadStream == null || currentDownloadId == null || !currentDownloadId.equals(id)) return false;
            try {
                byte[] bytes = Base64.decode(base64Chunk, Base64.DEFAULT);
                currentDownloadStream.write(bytes);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public synchronized boolean finishDownload(String id) {
            if (currentDownloadStream == null || currentDownloadUri == null || currentDownloadId == null
                    || !currentDownloadId.equals(id)) return false;
            try {
                currentDownloadStream.flush();
                currentDownloadStream.close();
                currentDownloadStream = null;
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(currentDownloadUri, values, null, null);
                currentDownloadUri = null;
                currentDownloadId = null;
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Audio guardado en Descargas", Toast.LENGTH_SHORT).show());
                return true;
            } catch (Exception e) {
                cancelCurrentDownload();
                return false;
            }
        }

        @JavascriptInterface
        public void shareText(final String text) {
            runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                    startActivity(Intent.createChooser(send, "Compartir app"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo abrir el menú de compartir.",
                            Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public synchronized void cancelDownload(String id) {
            if (currentDownloadId != null && currentDownloadId.equals(id)) cancelCurrentDownload();
        }
    }

    private static String sanitizeFilename(String filename) {
        String name = filename == null ? "audio.mp3" : filename.trim();
        name = name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_");
        name = name.replaceAll("^\\.+", "");
        if (name.isEmpty()) name = "audio.mp3";
        if (!name.toLowerCase(java.util.Locale.ROOT).endsWith(".mp3")) name += ".mp3";
        return name;
    }
}
