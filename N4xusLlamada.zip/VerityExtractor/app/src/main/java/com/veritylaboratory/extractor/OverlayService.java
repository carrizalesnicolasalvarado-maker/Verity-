package com.veritylaboratory.extractor;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** Panel de Nexus AI flotando encima de otras apps (necesita el permiso "Mostrar sobre otras apps"). */
public class OverlayService extends Service {
    private WindowManager wm;
    private LinearLayout root;
    private WebView web;
    private WindowManager.LayoutParams lp;
    private float density = 1f;
    private boolean big = false;
    private int normalW, normalH, screenW, screenH, savedY, savedH;
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (root == null) {
            try { buildOverlay(); } catch (Exception e) { stopSelf(); }
        }
        return START_NOT_STICKY;
    }

    private int dp(int v) {
        return (int) (v * density + 0.5f);
    }

    private TextView barButton(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(0xFF9FFBE6);
        t.setTextSize(17);
        t.setGravity(Gravity.CENTER);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(42), ViewGroup.LayoutParams.MATCH_PARENT));
        return t;
    }

    private void buildOverlay() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        density = dm.density;
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        normalW = Math.min(dp(340), screenW - dp(16));
        normalH = Math.min(dp(470), (int) (screenH * 0.68f));

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        lp = new WindowManager.LayoutParams(normalW, normalH, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(8);
        lp.y = dp(90);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF0A1F2A);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), 0xFF2FD6B4);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(bg);
        root.setPadding(dp(2), dp(2), dp(2), dp(2));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(12), 0, dp(2), 0);

        TextView title = new TextView(this);
        title.setText("🤖  NEXUS AI   ·  arrastra aquí");
        title.setTextColor(0xFF66F9D7);
        title.setTextSize(12);
        title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        TextView size = barButton("⤢");
        TextView close = barButton("✕");
        bar.addView(size);
        bar.addView(close);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));

        size.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleSize(); }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { stopSelf(); }
        });

        final int[] down = new int[4];
        bar.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        down[0] = (int) e.getRawX(); down[1] = (int) e.getRawY();
                        down[2] = lp.x; down[3] = lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = clamp(down[2] + (int) e.getRawX() - down[0], 0, Math.max(0, screenW - lp.width));
                        lp.y = clamp(down[3] + (int) e.getRawY() - down[1], 0, Math.max(0, screenH - lp.height));
                        try { wm.updateViewLayout(root, lp); } catch (Exception ignored) {}
                        return true;
                    default:
                        return true;
                }
            }
        });

        root.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_OUTSIDE) setWindowFocusable(false);
                return false;
            }
        });

        web = new WebView(getApplicationContext());
        web.setBackgroundColor(0xFF0A1F2A);
        WebSettings st = web.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setAllowFileAccess(true);
        st.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new OverlayBridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        root.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        web.loadUrl("file:///android_asset/nexus.html");

        wm.addView(root, lp);
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private void toggleSize() {
        big = !big;
        lp.width = big ? screenW - dp(16) : normalW;
        lp.height = big ? (int) (screenH * 0.82f) : normalH;
        lp.x = clamp(lp.x, 0, Math.max(0, screenW - lp.width));
        lp.y = clamp(lp.y, 0, Math.max(0, screenH - lp.height));
        try { wm.updateViewLayout(root, lp); } catch (Exception ignored) {}
    }

    /** La ventana solo toma el foco (para el teclado) mientras escribes; el resto del tiempo deja usar las otras apps. */
    private void setWindowFocusable(final boolean focusable) {
        main.post(new Runnable() {
            @Override public void run() {
                if (root == null || wm == null) return;
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (focusable) {
                    lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
                    savedY = lp.y;
                    savedH = lp.height;
                    lp.height = Math.min(lp.height, (int) (screenH * 0.5f));
                    lp.y = dp(24);
                } else {
                    lp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
                    if (savedH > 0) { lp.height = savedH; lp.y = savedY; savedH = 0; }
                    if (imm != null && web != null) imm.hideSoftInputFromWindow(web.getWindowToken(), 0);
                }
                try { wm.updateViewLayout(root, lp); } catch (Exception ignored) {}
                if (focusable && web != null) {
                    web.requestFocus();
                    final InputMethodManager im2 = imm;
                    web.postDelayed(new Runnable() {
                        @Override public void run() { if (im2 != null && web != null) im2.showSoftInput(web, InputMethodManager.SHOW_IMPLICIT); }
                    }, 150);
                }
            }
        });
    }

    @Override
    public void onDestroy() {
        try { if (root != null && wm != null) wm.removeView(root); } catch (Exception ignored) {}
        root = null;
        try { if (web != null) { web.destroy(); web = null; } } catch (Exception ignored) {}
        super.onDestroy();
    }

    private final class OverlayBridge {
        @JavascriptInterface
        public String nxGet(String key) {
            try { return getSharedPreferences("nexus", MODE_PRIVATE).getString(key, ""); } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public void nxSet(String key, String val) {
            try {
                SharedPreferences.Editor ed = getSharedPreferences("nexus", MODE_PRIVATE).edit();
                if (val == null || val.length() == 0) ed.remove(key); else ed.putString(key, val);
                ed.apply();
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void overlayFocus(boolean focusable) {
            setWindowFocusable(focusable);
        }

        @JavascriptInterface
        public void ttsSpeak(final String text) { Speaker.speak(OverlayService.this, text, null); }

        @JavascriptInterface
        public void voiceConfig(String lang, String voice, String rate, String pitch) { Speaker.configure(lang, voice, rate, pitch); }

        @JavascriptInterface
        public void ttsStop() { Speaker.stop(); }

        @JavascriptInterface
        public void openUrl(final String url) {
            if (url == null || !url.startsWith("https://wa.me/")) return;
            main.post(new Runnable() {
                @Override public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    } catch (Exception ignored) {}
                }
            });
        }

        @JavascriptInterface
        public void closeOverlay() {
            main.post(new Runnable() { @Override public void run() { stopSelf(); } });
        }

        @JavascriptInterface
        public void closeApp() {
            main.post(new Runnable() {
                @Override public void run() {
                    MainActivity a = MainActivity.instance;
                    if (a != null) {
                        try { a.finishAndRemoveTask(); } catch (Exception ignored) {}
                    }
                    stopSelf();
                }
            });
        }

        /** Pide a la pantalla principal de VERITY que ejecute una acción (Nexus ya tiene el permiso del usuario). */
        @JavascriptInterface
        public void nxAction(final String id, final String arg, final boolean front) {
            main.post(new Runnable() {
                @Override public void run() {
                    String safeId = id == null ? "" : id.replaceAll("[^a-z_]", "");
                    final String js = "window.nxDo&&window.nxDo(" + JSONObject.quote(safeId) + ","
                            + JSONObject.quote(arg == null ? "" : arg) + ")";
                    long delay = 0;
                    if (front || MainActivity.instance == null) {
                        try {
                            Intent i = new Intent(OverlayService.this, MainActivity.class);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            startActivity(i);
                        } catch (Exception ignored) {}
                        delay = MainActivity.instance == null ? 2500 : 500;
                    }
                    main.postDelayed(new Runnable() {
                        @Override public void run() {
                            MainActivity a = MainActivity.instance;
                            if (a != null) a.runJs(js);
                        }
                    }, delay);
                }
            });
        }
    }
}
