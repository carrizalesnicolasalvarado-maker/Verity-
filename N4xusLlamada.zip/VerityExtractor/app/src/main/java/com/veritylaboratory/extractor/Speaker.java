package com.veritylaboratory.extractor;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;
import java.util.Set;

/** Lee texto en voz alta con la voz del celular (idioma, voz, velocidad y tono configurables). */
final class Speaker {
    interface Done { void onDone(); }

    private static TextToSpeech tts;
    private static boolean ready = false;
    private static String pending = null;
    private static String lang = "es-MX", voiceName = "";
    private static float rate = 1f, pitch = 1f;
    private static volatile Done done = null;

    private Speaker() {}

    private static Locale loc(String l) {
        Locale x = Locale.forLanguageTag(l == null || l.length() == 0 ? "es-MX" : l);
        return x;
    }

    private static float num(String s, float d) {
        try { float f = Float.parseFloat(s); return (f < 0.3f || f > 3f) ? d : f; } catch (Exception e) { return d; }
    }

    static synchronized void configure(String l, String v, String r, String p) {
        if (l != null && l.length() > 0) lang = l;
        voiceName = v == null ? "" : v;
        rate = num(r, 1f);
        pitch = num(p, 1f);
        if (ready) applyCfg();
    }

    private static void applyCfg() {
        try {
            Locale lc = loc(lang);
            int r = tts.setLanguage(lc);
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(new Locale(lc.getLanguage()));
            }
            if (voiceName.length() > 0) {
                Set<Voice> vs = tts.getVoices();
                if (vs != null) for (Voice v : vs) {
                    if (voiceName.equals(v.getName())) { tts.setVoice(v); break; }
                }
            }
            tts.setSpeechRate(rate);
            tts.setPitch(pitch);
        } catch (Exception ignored) {}
    }

    static synchronized void init(Context c) {
        if (tts != null) return;
        tts = new TextToSpeech(c.getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override public void onInit(int status) {
                synchronized (Speaker.class) {
                    if (status == TextToSpeech.SUCCESS && tts != null) {
                        try {
                            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                                @Override public void onStart(String id) {}
                                @Override public void onDone(String id) { fire(); }
                                @Override public void onError(String id) { fire(); }
                            });
                        } catch (Exception ignored) {}
                        applyCfg();
                        ready = true;
                        if (pending != null) { say(pending); pending = null; }
                    } else {
                        Done d = done;
                        if (d != null) d.onDone();
                    }
                }
            }
        });
    }

    private static void fire() {
        Done d = done;
        if (d != null) { try { d.onDone(); } catch (Exception ignored) {} }
    }

    static synchronized void speak(Context c, String text, Done d) {
        if (text == null) return;
        done = d;
        if (text.length() > 3900) text = text.substring(0, 3900);
        if (tts == null) { pending = text; init(c); return; }
        if (ready) say(text); else pending = text;
    }

    private static void say(String t) {
        try { tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "nexus"); } catch (Exception ignored) { fire(); }
    }

    static synchronized void stop() {
        pending = null;
        try { if (tts != null) tts.stop(); } catch (Exception ignored) {}
    }

    /** Lista de voces instaladas: [{n:nombre, l:idioma, o:requiere internet}] */
    static synchronized String voicesJson(Context c) {
        init(c);
        JSONArray a = new JSONArray();
        if (!ready) return a.toString();
        try {
            Set<Voice> vs = tts.getVoices();
            if (vs != null) for (Voice v : vs) {
                JSONObject o = new JSONObject();
                o.put("n", v.getName());
                o.put("l", v.getLocale().toLanguageTag());
                o.put("o", v.isNetworkConnectionRequired());
                a.put(o);
            }
        } catch (Exception ignored) {}
        return a.toString();
    }

    /** "ok", "missing" o "wait" (aún iniciando) para el idioma pedido. */
    static synchronized String langStatus(Context c, String l) {
        init(c);
        if (!ready) return "wait";
        try {
            int r = tts.isLanguageAvailable(loc(l));
            return r >= TextToSpeech.LANG_AVAILABLE ? "ok" : "missing";
        } catch (Exception e) { return "ok"; }
    }
}
