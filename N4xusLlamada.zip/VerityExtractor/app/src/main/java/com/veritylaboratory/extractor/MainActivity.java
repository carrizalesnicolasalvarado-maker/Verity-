package com.veritylaboratory.extractor;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.os.Build;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.UUID;

import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int FILE_PICKER_REQUEST = 4102;
    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private Uri currentDownloadUri;
    private OutputStream currentDownloadStream;
    private String currentDownloadId;
    private volatile boolean inForeground = true;
    private int activeJobs = 0;
    private int notifId = 8000;
    private static final String CH_READY = "vx_ready";
    static MainActivity instance;
    private SpeechRecognizer recognizer;
    private String micLang = "es-MX";
    private String lastPartial = "";
    private long lastRms = 0;
    private static final int REQ_MIC = 4104;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(0xFF030811);
        window.setNavigationBarColor(0xFF030811);
        window.getDecorView().setSystemUiVisibility(0);

        instance = this;
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF030811);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new AndroidDownloadBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileChooserCallback != null) {
                    fileChooserCallback.onReceiveValue(null);
                }
                fileChooserCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"video/*", "image/*"});
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,
                        params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(Intent.createChooser(intent, "Elige un video o una imagen"),
                            FILE_PICKER_REQUEST);
                } catch (Exception e) {
                    fileChooserCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "No se pudo abrir el selector de archivos.",
                            Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_PICKER_REQUEST || fileChooserCallback == null) return;
        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                results = new Uri[count];
                for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
        }
        fileChooserCallback.onReceiveValue(results);
        fileChooserCallback = null;
    }

    @Override
    protected void onResume() {
        super.onResume();
        inForeground = true;
    }

    @Override
    protected void onPause() {
        inForeground = false;
        super.onPause();
    }

    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { runJs("window.nxMicError&&window.nxMicError(-1)"); return; }
        try {
            if (recognizer != null) { try { recognizer.cancel(); recognizer.destroy(); } catch (Exception ignored) {} recognizer = null; }
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
                recognizer.setRecognitionListener(new RecognitionListener() {
                    @Override public void onReadyForSpeech(Bundle params) { runJs("window.nxMicReady&&window.nxMicReady()"); }
                    @Override public void onBeginningOfSpeech() {}
                    @Override public void onRmsChanged(float rmsdB) {
                        long n = System.currentTimeMillis();
                        if (n - lastRms < 110) return;
                        lastRms = n;
                        float lv = (rmsdB + 2f) / 12f; if (lv < 0) lv = 0; if (lv > 1) lv = 1;
                        runJs("window.nxMicLevel&&window.nxMicLevel(" + lv + ")");
                    }
                    @Override public void onBufferReceived(byte[] buffer) {}
                    @Override public void onEndOfSpeech() {}
                    @Override public void onError(int error) { runJs("window.nxMicError&&window.nxMicError(" + error + ")"); }
                    @Override public void onResults(Bundle results) {
                        ArrayList<String> l = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        String t = (l != null && !l.isEmpty()) ? l.get(0) : "";
                        if (t.trim().length() == 0) t = lastPartial;
                        runJs("window.nxMicResult&&window.nxMicResult(" + JSONObject.quote(t) + ")");
                    }
                    @Override public void onPartialResults(Bundle partial) {
                        ArrayList<String> l = partial == null ? null : partial.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (l != null && !l.isEmpty()) lastPartial = l.get(0);
                        if (l != null && !l.isEmpty()) runJs("window.nxMicPartial&&window.nxMicPartial(" + JSONObject.quote(l.get(0)) + ")");
                    }
                    @Override public void onEvent(int eventType, Bundle params) {}
                });
            }
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, micLang);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L);
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L);
            lastPartial = "";
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
            recognizer.startListening(i);
        } catch (Exception e) {
            runJs("window.nxMicError&&window.nxMicError(-2)");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                runJs("window.nxMicGranted&&window.nxMicGranted()");
            } else {
                runJs("window.nxMicError&&window.nxMicError(9)");
            }
        }
    }

    @Override
    protected void onStop() {
        try { if (recognizer != null) recognizer.cancel(); } catch (Exception ignored) {}
        Speaker.stop();
        runJs("window.nxPause&&window.nxPause()");
        super.onStop();
    }

    void runJs(final String js) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try { if (webView != null) webView.evaluateJavascript(js, null); } catch (Exception ignored) {}
            }
        });
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            try { requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4103); } catch (Exception ignored) {}
        }
    }

    private void showReadyNotification(String title, String text) {
        try {
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            nm.createNotificationChannel(new NotificationChannel(CH_READY, "Audio listo", NotificationManager.IMPORTANCE_DEFAULT));
            Intent open = new Intent(this, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(this, CH_READY)
                    .setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build();
            nm.notify(notifId++, n);
        } catch (Exception ignored) {}
    }

    private void startWorkService() {
        try {
            Intent i = new Intent(this, ExtractService.class);
            startForegroundService(i);
        } catch (Exception ignored) {}
    }

    private void stopWorkService() {
        try { stopService(new Intent(this, ExtractService.class)); } catch (Exception ignored) {}
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (fileChooserCallback != null) {
            fileChooserCallback.onReceiveValue(null);
            fileChooserCallback = null;
        }
        cancelCurrentDownload();
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
            webView = null;
        }
        if (instance == this) instance = null;
        super.onDestroy();
    }

    private synchronized void cancelCurrentDownload() {
        try { if (currentDownloadStream != null) currentDownloadStream.close(); } catch (Exception ignored) {}
        currentDownloadStream = null;
        if (currentDownloadUri != null) {
            try { getContentResolver().delete(currentDownloadUri, null, null); } catch (Exception ignored) {}
        }
        currentDownloadUri = null;
        currentDownloadId = null;
    }

    private final class AndroidDownloadBridge {
        @JavascriptInterface
        public synchronized String beginDownload(String requestedName, String mimeType) {
            cancelCurrentDownload();
            try {
                String safeName = sanitizeFilename(requestedName);
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
                values.put(MediaStore.MediaColumns.MIME_TYPE,
                        mimeType == null || mimeType.trim().isEmpty() ? "audio/mpeg" : mimeType);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                currentDownloadUri = getContentResolver().insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (currentDownloadUri == null) return "";
                currentDownloadStream = getContentResolver().openOutputStream(currentDownloadUri, "w");
                if (currentDownloadStream == null) {
                    getContentResolver().delete(currentDownloadUri, null, null);
                    currentDownloadUri = null;
                    return "";
                }
                currentDownloadId = UUID.randomUUID().toString();
                return currentDownloadId;
            } catch (Exception e) {
                cancelCurrentDownload();
                return "";
            }
        }

        @JavascriptInterface
        public synchronized boolean appendDownloadChunk(String id, String base64Chunk) {
            if (currentDownloadStream == null || currentDownloadId == null || !currentDownloadId.equals(id)) return false;
            try {
                byte[] bytes = Base64.decode(base64Chunk, Base64.DEFAULT);
                currentDownloadStream.write(bytes);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public synchronized boolean finishDownload(String id) {
            if (currentDownloadStream == null || currentDownloadUri == null || currentDownloadId == null
                    || !currentDownloadId.equals(id)) return false;
            try {
                currentDownloadStream.flush();
                currentDownloadStream.close();
                currentDownloadStream = null;
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(currentDownloadUri, values, null, null);
                currentDownloadUri = null;
                currentDownloadId = null;
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Audio guardado en Descargas", Toast.LENGTH_SHORT).show());
                return true;
            } catch (Exception e) {
                cancelCurrentDownload();
                return false;
            }
        }

        @JavascriptInterface
        public String nxGet(String key) {
            try { return getSharedPreferences("nexus", MODE_PRIVATE).getString(key, ""); } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public void nxSet(String key, String val) {
            try {
                SharedPreferences.Editor ed = getSharedPreferences("nexus", MODE_PRIVATE).edit();
                if (val == null || val.length() == 0) ed.remove(key); else ed.putString(key, val);
                ed.apply();
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public String micStart() {
            if (Build.VERSION.SDK_INT >= 23
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        try { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC); } catch (Exception ignored) {}
                    }
                });
                return "perm";
            }
            runOnUiThread(new Runnable() { @Override public void run() { startListening(); } });
            return "ok";
        }

        @JavascriptInterface
        public void micStop() {
            runOnUiThread(new Runnable() {
                @Override public void run() { try { if (recognizer != null) recognizer.stopListening(); } catch (Exception ignored) {} }
            });
        }

        @JavascriptInterface
        public void micCancel() {
            runOnUiThread(new Runnable() {
                @Override public void run() { try { if (recognizer != null) recognizer.cancel(); } catch (Exception ignored) {} }
            });
        }

        @JavascriptInterface
        public void ttsSpeak(final String text) {
            Speaker.speak(MainActivity.this, text, new Speaker.Done() {
                @Override public void onDone() { runJs("window.nxTtsDone&&window.nxTtsDone()"); }
            });
        }

        @JavascriptInterface
        public void voiceConfig(String lang, String voice, String rate, String pitch) {
            if (lang != null && lang.length() > 0) micLang = lang;
            Speaker.configure(lang, voice, rate, pitch);
        }

        @JavascriptInterface
        public String ttsVoices() { return Speaker.voicesJson(MainActivity.this); }

        @JavascriptInterface
        public String ttsLangOk(String lang) { return Speaker.langStatus(MainActivity.this, lang); }

        @JavascriptInterface
        public void ttsStop() { Speaker.stop(); }

        @JavascriptInterface
        public void openUrl(final String url) {
            if (url == null || !url.startsWith("https://wa.me/")) return;
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                    catch (Exception e) { Toast.makeText(MainActivity.this, "No se pudo abrir WhatsApp", Toast.LENGTH_LONG).show(); }
                }
            });
        }

        @JavascriptInterface
        public String overlayStart() {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(MainActivity.this)) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        try {
                            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:" + getPackageName()));
                            startActivity(i);
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Activa 'Mostrar sobre otras apps' en los ajustes de la app.",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                });
                return "perm";
            }
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try { startService(new Intent(MainActivity.this, OverlayService.class)); } catch (Exception ignored) {}
                }
            });
            return "ok";
        }

        @JavascriptInterface
        public void overlayStop() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try { stopService(new Intent(MainActivity.this, OverlayService.class)); } catch (Exception ignored) {}
                }
            });
        }

        @JavascriptInterface
        public void closeApp() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try { stopService(new Intent(MainActivity.this, OverlayService.class)); } catch (Exception ignored) {}
                    try { stopService(new Intent(MainActivity.this, ExtractService.class)); } catch (Exception ignored) {}
                    finishAndRemoveTask();
                }
            });
        }

        @JavascriptInterface
        public void jobStart() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    activeJobs++;
                    if (activeJobs == 1) {
                        askNotificationPermission();
                        startWorkService();
                    }
                }
            });
        }

        @JavascriptInterface
        public void jobEnd(final String title, final String text, final boolean notify) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (activeJobs > 0) activeJobs--;
                    if (notify && !inForeground) showReadyNotification(title, text);
                    if (activeJobs == 0) stopWorkService();
                }
            });
        }

        @JavascriptInterface
        public void shareText(final String text) {
            runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                    startActivity(Intent.createChooser(send, "Compartir app"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo abrir el menú de compartir.",
                            Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public synchronized void cancelDownload(String id) {
            if (currentDownloadId != null && currentDownloadId.equals(id)) cancelCurrentDownload();
        }
    }

    private static String sanitizeFilename(String filename) {
        String name = filename == null ? "audio.mp3" : filename.trim();
        name = name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_");
        name = name.replaceAll("^\\.+", "");
        if (name.isEmpty()) name = "audio.mp3";
        if (!name.toLowerCase(java.util.Locale.ROOT).endsWith(".mp3")) name += ".mp3";
        return name;
    }
}
