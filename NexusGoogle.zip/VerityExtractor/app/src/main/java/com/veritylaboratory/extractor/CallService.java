package com.veritylaboratory.extractor;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/** Mantiene viva la llamada con Nexus (y el micrófono) aunque salgas de la app. */
public class CallService extends Service {
    private static final String CH = "vx_call";

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "hang".equals(intent.getAction())) {
            Mic.Sink s = Mic.callSink;
            if (s != null) s.js("window.nxHang&&window.nxHang()");
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(CH, "Llamada con Nexus", NotificationManager.IMPORTANCE_LOW));
            Intent open = new Intent(this, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Intent hang = new Intent(this, CallService.class).setAction("hang");
            PendingIntent ph = PendingIntent.getService(this, 1, hang, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(this, CH)
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle("Llamada con Nexus AI")
                    .setContentText("Sigue hablando con Nexus. Toca para volver.")
                    .setContentIntent(pi)
                    .addAction(new Notification.Action.Builder(null, "Colgar", ph).build())
                    .setOngoing(true)
                    .build();
            if (Build.VERSION.SDK_INT >= 30) startForeground(7002, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            else startForeground(7002, n);
        } catch (Exception e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }
}
