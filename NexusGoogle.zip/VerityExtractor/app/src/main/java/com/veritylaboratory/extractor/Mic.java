package com.veritylaboratory.extractor;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import org.json.JSONObject;

import java.util.ArrayList;

/** Micrófono compartido (pantalla principal y panel superpuesto). Usa el reconocedor de Google obligatoriamente cuando existe. */
final class Mic {
    interface Sink { void js(String code); }

    static final String GOOGLE_PKG = "com.google.android.googlequicksearchbox";
    private static final String GOOGLE_SVC = "com.google.android.voicesearch.serviceapi.GoogleRecognitionService";

    private static SpeechRecognizer rec;
    private static String lastPartial = "";
    private static long lastRms = 0;
    private static Sink sink;
    /** Quién inició la llamada (para el botón Colgar de la notificación). */
    static volatile Sink callSink;

    private Mic() {}

    static boolean googleAvailable(Context c) {
        try {
            c.getPackageManager().getServiceInfo(new ComponentName(GOOGLE_PKG, GOOGLE_SVC), 0);
            return true;
        } catch (Exception e) { return false; }
    }

    static boolean hasPermission(Context c) {
        return android.os.Build.VERSION.SDK_INT < 23
                || c.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private static void err(int code) { Sink s = sink; if (s != null) s.js("window.nxMicError&&window.nxMicError(" + code + ")"); }

    /** Siempre desde el hilo principal. */
    static void start(Context c, Sink s, String lang, boolean fast) {
        sink = s;
        Context app = c.getApplicationContext();
        if (!SpeechRecognizer.isRecognitionAvailable(app) && !googleAvailable(app)) { err(-1); return; }
        try {
            cancel();
            SpeechRecognizer r = null;
            try {
                if (googleAvailable(app)) r = SpeechRecognizer.createSpeechRecognizer(app, new ComponentName(GOOGLE_PKG, GOOGLE_SVC));
            } catch (Exception ignored) { r = null; }
            if (r == null) r = SpeechRecognizer.createSpeechRecognizer(app);
            rec = r;
            r.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle p) { Sink x = sink; if (x != null) x.js("window.nxMicReady&&window.nxMicReady()"); }
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float db) {
                    long n = System.currentTimeMillis();
                    if (n - lastRms < 110) return;
                    lastRms = n;
                    float lv = (db + 2f) / 12f; if (lv < 0) lv = 0; if (lv > 1) lv = 1;
                    Sink x = sink; if (x != null) x.js("window.nxMicLevel&&window.nxMicLevel(" + lv + ")");
                }
                @Override public void onBufferReceived(byte[] b) {}
                @Override public void onEndOfSpeech() {}
                @Override public void onError(int e) { err(e); }
                @Override public void onResults(Bundle res) {
                    ArrayList<String> l = res == null ? null : res.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String t = (l != null && !l.isEmpty()) ? l.get(0) : "";
                    if (t.trim().length() == 0) t = lastPartial;
                    Sink x = sink; if (x != null) x.js("window.nxMicResult&&window.nxMicResult(" + JSONObject.quote(t) + ")");
                }
                @Override public void onPartialResults(Bundle p) {
                    ArrayList<String> l = p == null ? null : p.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (l != null && !l.isEmpty()) {
                        lastPartial = l.get(0);
                        Sink x = sink; if (x != null) x.js("window.nxMicPartial&&window.nxMicPartial(" + JSONObject.quote(lastPartial) + ")");
                    }
                }
                @Override public void onEvent(int t, Bundle p) {}
            });
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang == null || lang.length() == 0 ? "es-MX" : lang);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, fast ? 1100L : 1800L);
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, fast ? 900L : 1500L);
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, app.getPackageName());
            lastPartial = "";
            r.startListening(i);
        } catch (Exception e) {
            err(-2);
        }
    }

    static void cancel() {
        try { if (rec != null) { rec.cancel(); rec.destroy(); } } catch (Exception ignored) {}
        rec = null;
    }
}
