package com.veritylaboratory.extractor;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;

/** Lee texto en voz alta con la voz del celular. Admite leer por frases mientras llega la respuesta (más rápido). */
final class Speaker {
    interface Done { void onDone(); }

    private static TextToSpeech tts;
    private static boolean ready = false;
    private static final ArrayList<String> pend = new ArrayList<String>();
    private static String lang = "es-MX", voiceName = "";
    private static float rate = 1f, pitch = 1f;
    private static volatile Done done = null;
    private static int outstanding = 0, seq = 0;
    private static boolean closed = true, active = false;

    private Speaker() {}

    private static Locale loc(String l) { return Locale.forLanguageTag(l == null || l.length() == 0 ? "es-MX" : l); }

    private static float num(String s, float d) {
        try { float f = Float.parseFloat(s); return (f < 0.3f || f > 3f) ? d : f; } catch (Exception e) { return d; }
    }

    static synchronized void configure(String l, String v, String r, String p) {
        if (l != null && l.length() > 0) lang = l;
        voiceName = v == null ? "" : v;
        rate = num(r, 1f);
        pitch = num(p, 1f);
        if (ready) applyCfg();
    }

    private static void applyCfg() {
        try {
            Locale lc = loc(lang);
            int r = tts.setLanguage(lc);
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(new Locale(lc.getLanguage()));
            if (voiceName.length() > 0) {
                Set<Voice> vs = tts.getVoices();
                if (vs != null) for (Voice v : vs) if (voiceName.equals(v.getName())) { tts.setVoice(v); break; }
            }
            tts.setSpeechRate(rate);
            tts.setPitch(pitch);
        } catch (Exception ignored) {}
    }

    static synchronized void init(Context c) {
        if (tts != null) return;
        tts = new TextToSpeech(c.getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override public void onInit(int status) {
                synchronized (Speaker.class) {
                    if (status == TextToSpeech.SUCCESS && tts != null) {
                        try {
                            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                                @Override public void onStart(String id) {}
                                @Override public void onDone(String id) { finished(); }
                                @Override public void onError(String id) { finished(); }
                            });
                        } catch (Exception ignored) {}
                        applyCfg();
                        ready = true;
                        for (String s : pend) enqueue(s);
                        pend.clear();
                        check();
                    } else {
                        active = false;
                        fire();
                    }
                }
            }
        });
    }

    private static void fire() {
        Done d = done;
        if (d != null) { try { d.onDone(); } catch (Exception ignored) {} }
    }

    private static synchronized void finished() {
        if (outstanding > 0) outstanding--;
        check();
    }

    private static void check() {
        if (active && closed && outstanding <= 0 && pend.isEmpty()) { active = false; fire(); }
    }

    private static void enqueue(String t) {
        outstanding++;
        try { tts.speak(t, TextToSpeech.QUEUE_ADD, null, "nx" + (seq++)); } catch (Exception e) { outstanding--; }
    }

    /** Empieza una lectura nueva (corta la anterior). */
    static synchronized void begin(Context c, Done d) {
        try { if (tts != null) tts.stop(); } catch (Exception ignored) {}
        pend.clear(); outstanding = 0; closed = false; active = true; done = d;
        init(c);
    }

    static synchronized void add(Context c, String text) {
        if (text == null || text.trim().length() == 0) return;
        if (text.length() > 3900) text = text.substring(0, 3900);
        if (!ready) { pend.add(text); init(c); return; }
        enqueue(text);
    }

    static synchronized void end() { closed = true; check(); }

    static synchronized void speak(Context c, String text, Done d) {
        begin(c, d);
        add(c, text);
        end();
    }

    static synchronized void stop() {
        pend.clear(); outstanding = 0; closed = true; active = false;
        try { if (tts != null) tts.stop(); } catch (Exception ignored) {}
    }

    static synchronized String voicesJson(Context c) {
        init(c);
        JSONArray a = new JSONArray();
        if (!ready) return a.toString();
        try {
            Set<Voice> vs = tts.getVoices();
            if (vs != null) for (Voice v : vs) {
                JSONObject o = new JSONObject();
                o.put("n", v.getName());
                o.put("l", v.getLocale().toLanguageTag());
                o.put("o", v.isNetworkConnectionRequired());
                a.put(o);
            }
        } catch (Exception ignored) {}
        return a.toString();
    }

    static synchronized String langStatus(Context c, String l) {
        init(c);
        if (!ready) return "wait";
        try { return tts.isLanguageAvailable(loc(l)) >= TextToSpeech.LANG_AVAILABLE ? "ok" : "missing"; } catch (Exception e) { return "ok"; }
    }
}
